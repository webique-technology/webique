import React from 'react'

const AccordionComponent = () => {
  return (
    <div>AccordionComponent</div>
  )
}

export default AccordionComponent