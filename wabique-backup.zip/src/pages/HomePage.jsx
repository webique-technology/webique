import React, { useEffect, useRef } from "react";
import Header from "../components/header";
// import WhatWeOffer from "../components/WhatWeOffer";
import gsap from 'gsap';
import { MotionPathPlugin } from 'gsap/MotionPathPlugin';
import ChooseAgencySec from "../components/ChooseAgencySec";
import WorldwideBusiness from "../components/WorldwideBusiness";
import IndusterySliders from "../components/industerySliders";
import TestimonialCarousel from "../components/TestimonialCarousel";
import { StackSlider } from "../components/WhatWeOffer";
import PricingSection from "../components/pricing";

gsap.registerPlugin(MotionPathPlugin);

const Home = () => {

    return (
        <>
            <Header />
            <ChooseAgencySec />

            {/* <WhatWeOffer /> */}
            <StackSlider />
            <WorldwideBusiness />
            <PricingSection />
            <IndusterySliders />
            <TestimonialCarousel />


            {/* <CurveArrow /> */}
        </>
    )
}

export default Home;