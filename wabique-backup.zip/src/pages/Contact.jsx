import { useState } from "react";
import { Container, Row, Col, Form, Button } from "react-bootstrap";
import "../style/contact.scss"

// images
import address from "../assets/images/address.png"
import mail from "../assets/images/mail.png"
import phone from "../assets/images/phone.png"
import linkArrow from "../assets/images/link-arrow.png"
import insta from "../assets/images/insta-cp.png"
import facebook from "../assets/images/fb-cp.png"
import linkedin from "../assets/images/linkedin-cp.png"
import twitterX from "../assets/images/x-cp.png"
import { span } from "motion/react-client";

// faq Accordian data
const accordionData = [
    {
        id: 1,
        title: "Faq quest",
        content: "We design experiences starting from mobile screens first, ensuring fast performance and seamless scaling.",
    },
    {
        id: 2,
        title: "Faq quest",
        content: "Our code follows best security practices to protect applications from vulnerabilities.",
    },
    {
        id: 3,
        title: "Faq quest",
        content: "Layouts are optimized for touch interactions and progressively enhanced for larger screens.",
    },
    {
        id: 4,
        title: "Faq quest",
        content: "Clean and semantic HTML structures improve search engine visibility and indexing.",
    },
];

// use for text fields
export const TextField = ({
    label,
    type = "text",
    value: controlledValue,
    onChange,
    isInvalid,
    ...props
}) => {
    const [focused, setFocused] = useState(false);
    const [internalValue, setInternalValue] = useState("");

    const value = controlledValue ?? internalValue;

    const handleChange = (e) => {
        if (onChange) {
            onChange(e);
        } else {
            setInternalValue(e.target.value);
        }
    };

    return (
        <div
            className={`float-field ${focused || value ? "active" : ""} ${isInvalid ? "is-invalid" : ""}`}
            onClick={() => setFocused(true)}
        >
            <input
                type={type}
                value={value}
                onChange={handleChange}
                onFocus={() => setFocused(true)}
                onBlur={() => !value && setFocused(false)}
                {...props}
            />

            <label>{label}</label>
            <fieldset>
                <legend>{label}</legend>
            </fieldset>
        </div>
    );
};

// use for links count
export const ContactLink = ({ linkImg, linkName, link, linkPath }) => {
    let href = "#"; // default

    if (linkPath) {
        href = linkPath;
    } else if (/\S+@\S+\.\S+/.test(link)) {
        // If it's an email
        href = `mailto:${link}`;
    } else if (/^\d+$/.test(link)) {
        // If it's a phone number
        href = `tel:+91${link}`;
    }

    return (
        <div className="cl-count">
            <div className="cl-img">
                <img src={linkImg} alt={linkName} className="" />
            </div>
            <div className="d-flex flex-column align-items-start justify-content-start ps-4">
                <h5 className="mb-1">{linkName}</h5>
                <a href={href} target={href.startsWith("http") ? "_blank" : "_self"} rel="noreferrer">
                    {link}
                </a>
            </div>
            <div className="circle-btn d-none d-sm-flex">
                <img src={linkArrow} alt="" />
            </div>
        </div>
    );
};

const socialLinkData = [
    {
        src: facebook,
        link: "www.facebook.com",
        alt: "facebook"
    },
    {
        src: insta,
        link: "www.insta.com",
        alt: "instagram"
    },
    {
        src: linkedin,
        link: "www.linkedin.com",
        alt: "linkedin"
    },
    {
        src: twitterX,
        link: "www.x.com",
        alt: "twitterX"
    },
]

// main page component
const Contact = () => {
    const [activeId, setActiveId] = useState(1);
    const [validated, setValidated] = useState(false);

    // form
    const [form, setForm] = useState({
        fullName: "",
        email: "",
        phone: "",
        subject: "",
    });

    // console.log("form data:", form);
    // handle submit for form submit
    const handleSubmit = (e) => {
        e.preventDefault();

        const formElement = e.currentTarget;

        if (formElement.checkValidity() === false) {
            e.stopPropagation();
        }

        setValidated(true);
    };

    // for accordian toggel
    const toggleAccordion = (id) => {
        setActiveId(activeId === id ? null : id);
    };

    const activeItem = accordionData.find(
        (item) => item.id === activeId
    );

    return (
        <>
            <section className='section-padding contact-section'>
                <Container className="d-flex flex-column row-gap-5 row-gap-md-5">
                    {/* title content  */}
                    <div className="title-content title-gap align-items-center mb-0">
                        <h2 className="text-center m-0">Let’s talk about your journey </h2>
                        <p className="text-center m-0">
                            We’re here to answer your questions, guide your steps, and help you take control of your money with confidence.
                        </p>
                    </div>
                    {/* contact form and contact links */}
                    <div className="contact-content-container">
                        <Row className="justify-content-between row-gap-5 row-gap-md-5">
                            {/* col for contact form */}
                            <Col xs={{ order: 2, span: 12 }} lg={{ order: 1, span: 6 }}>
                                <div className="contact-form">
                                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                                        <Row className="mb-3 row-gap-2 row-gap-md-4">
                                            <Col md={6}>
                                                <Form.Label className="m-0 d-none">Full Name</Form.Label>
                                                <TextField
                                                    label="Full name"
                                                    name="fullName"
                                                    required
                                                    value={form.fullName}
                                                    onChange={(e) =>
                                                        setForm({ ...form, fullName: e.target.value })
                                                    }
                                                    isInvalid={validated && !form.fullName}
                                                />

                                                {validated && !form.fullName && (
                                                    <div className="invalid-feedback d-block">
                                                        Please enter your name.
                                                    </div>
                                                )}
                                            </Col>

                                            <Col md={6}>
                                                <Form.Label className="m-0 d-none">Email</Form.Label>
                                                <TextField
                                                    label="Email"
                                                    name="email"
                                                    required
                                                    value={form.email}
                                                    onChange={(e) =>
                                                        setForm({ ...form, email: e.target.value })
                                                    }
                                                    isInvalid={validated && !form.email}
                                                />

                                                {validated && !form.email && (
                                                    <div className="invalid-feedback d-block">
                                                        Please enter your email.
                                                    </div>
                                                )}
                                            </Col>

                                            <Col md={6}>
                                                <Form.Label className="m-0 d-none">Phone number</Form.Label>
                                                <TextField
                                                    label="Phone number"
                                                    name="phone"
                                                    required
                                                    type="number"
                                                    value={form.phone}
                                                    onChange={(e) =>
                                                        setForm({ ...form, phone: e.target.value })
                                                    }
                                                    isInvalid={validated && !form.phone}
                                                />

                                                {validated && !form.phone && (
                                                    <div className="invalid-feedback d-block">
                                                        Please enter your phone number.
                                                    </div>
                                                )}
                                            </Col>

                                            <Col md={6}>
                                                <Form.Label className="m-0 d-none">Subject</Form.Label>
                                                <TextField
                                                    label="Subject"
                                                    name="subject"
                                                    required
                                                    value={form.subject}
                                                    onChange={(e) =>
                                                        setForm({ ...form, subject: e.target.value })
                                                    }
                                                    isInvalid={validated && !form.subject}
                                                />

                                                {validated && !form.subject && (
                                                    <div className="invalid-feedback d-block">
                                                        Please enter your subject.
                                                    </div>
                                                )}
                                            </Col>
                                        </Row>
                                        <Form.Group className="mb-4">
                                            <Form.Label>Message</Form.Label>
                                            <Form.Control
                                                required
                                                as="textarea"
                                                rows={4}
                                            />
                                            <Form.Control.Feedback type="invalid">
                                                Please enter a message.
                                            </Form.Control.Feedback>
                                        </Form.Group>

                                        <Button type="submit" className="send-btn">
                                            Send message
                                        </Button>
                                    </Form>
                                </div>
                            </Col>
                            {/* col for contact links */}
                            <Col xs={{ order: 1, span: 12 }} lg={{ order: 2, span: 5 }}>
                                <div className="contact-links-count d-flex flex-column gap-4">
                                    <Row className="row-gap-4">
                                        <Col sm={12}>
                                            <ContactLink
                                                linkImg={address}
                                                linkName="Address"
                                                linkPath="https://maps.app.goo.gl/iNPJVhtMfUWuNWHz8"
                                                link="G-110, Atlanta Shoppers, Pathardi road, Pathardi Phata, Nashik-422010"
                                            />
                                        </Col>
                                        <Col sm={12} md={6} lg={12}>
                                            <ContactLink
                                                linkImg={mail}
                                                linkName="Send us an email"
                                                linkPath=""
                                                link="contact@webique.in"
                                            />
                                        </Col>
                                        <Col sm={12} md={6} lg={12}>
                                            <ContactLink
                                                linkImg={phone}
                                                linkName="Give us a call"
                                                linkPath=""
                                                link="9860188007"
                                            />
                                        </Col>
                                    </Row>
                                    {/* social links */}
                                    <div className="social-links">
                                        <h4 className="mb-1">Follow us on social media</h4>
                                        <p className="mb-2">Connect with us on your favorite platforms to see
                                            our latest work, company updates, and insights.</p>
                                        <ul className="d-flex gap-3 align-items-center">
                                            {socialLinkData.map((item, i) => {
                                                return (
                                                    <li key={i}>
                                                        <a href={item.link}>
                                                            <img src={item.src} alt={item.alt} />
                                                        </a>
                                                    </li>
                                                )
                                            })}
                                        </ul>
                                    </div>
                                </div>
                            </Col>
                        </Row>
                    </div>
                    {/* map section */}
                    <div className="map-conatiner pb-4 pb-md-0">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4487.666904269915!2d73.7666468!3d19.9537683!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdd95f5ba76ff57%3A0x44e1830bb9d40a86!2sWebique%20technology!5e1!3m2!1sen!2sin!4v1768369224159!5m2!1sen!2sin"
                            width="100%"
                            height="100%"
                            className="map"
                            loading="lazy"
                            referrerPolicy="no-referrer-when-downgrade"
                        ></iframe>
                    </div>
                </Container>
            </section>
        </>
    )
}

export default Contact


// faq 
{/* faq & accordian */ }
{/* <div className="faq-container">
    <Row>
        <Col sm={12} md={12} lg={6}>
            <div className="title-content faq-content">
                <h2>
                    Frequently asked questions
                </h2>
                <p className="w-100">Find quick answers to common questions about using
                    Fintiq, security, transfers, savings, and more.</p>
            </div>
        </Col>
        <Col sm={12} md={12} lg={6}>
            <div className="accordion-wrap">
                {accordionData.map((item) => (
                    <div
                        key={item.id}
                        className={`accordion-item ${activeId === item.id ? "active" : ""
                            }`}
                    >
                        <button
                            className="accordion-header"
                            onClick={() => setActiveId(item.id)}
                        >
                            <span className="title">{item.title} {item.id}</span>
                            <span className="icon">
                                {activeId === item.id ? "−" : "+"}
                            </span>
                        </button>
                        <div className="accordion-content">
                            <div className="accordion-inner">
                                <p>{item.content}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </Col>
    </Row>
</div> */}